package org.jboss.tools.tests.as;

public class HelloWorld {

	public static String sayHello(){
		return "Hello tests!";
	}
}
